# MediAlert
Medicine Reminder App built using Firebase
